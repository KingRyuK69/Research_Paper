% Prompt the user to input the number of rows and columns for t_dh
n_dh = input('Enter the number of departments in the network: ');
m_dh = input('Enter the number of hospitals in the network: ');

% Prompt the user to input the number of rows and columns for t_h
%n_h = input('Enter the number of rows and columns for t_h: ');
m_h =m_dh;
n_h=m_dh;

% Generate random values for t_dh and t_h
% Random graph generation of inter_layer network( department-Hospital )
t_dh = rand(n_dh, m_dh);

% Random graph generation of intra_layer network( Hospital-Hospital )
t_h = rand(n_h, m_h);
% Set the diagonal elements of t_h to 0
t_h(1:n_h+1:end) = 0;

% Loop to incorporate some Zeros randomly in the t_dh matrix
r=0
c=0
for i=0:5
    r = randi(n_dh)
    c = randi(m_dh)
    t_dh(r,c)=0
end
% Normalize the matrices so that the rows of t_dh and the columns of t_h all sum to 1
t_dh = t_dh ./ sum(t_dh, 2);
t_h = t_h ./ sum(t_h, 2);


% Display Network Matrix Visualize the data
disp("Hospital Network:");
disp(t_h)
disp("Department-Hospital Network:");
disp(t_dh)
% Initialize tol
tol = 0.01;

% Set the number of runs for the loop
num_runs = 9;
d_temp=0.0;

% Open a new file to store the output
file = fopen('output.txt', 'w');

% Loop over the range of inputs for h and d
for i = 1:num_runs

    % Generate random values for h and d within the range of 0.1 to 0.9
    d_temp=d_temp+0.1;
    d = repelem(d_temp,n_dh);
    h_temp=0.0;
    disp(d);
    for j=1:num_runs
        h_temp=h_temp+0.1;
        h = repelem(h_temp,m_dh);
        disp(h);
        % Calculate the matrix S using the formula S = h + d * t_dh
        S = h + d * t_dh;

        % Display the resulting matrix S
        disp(S)
        % Set a while loop with a condition 
        while true

            % Calculate the matrix S1 using the formula S1 = S * t_h
            S1 = S * t_h;

            % Write the values of S1 to the file
            %fprintf(file, '%f ', S1);
            %fprintf(file, '\n');

            % Calculate the difference C between S1 and S
            C = S1 - S;  

            % Print the current value of norm(C)
            %fprintf('Current value : %f\n', norm(C));

            % If the norm of C is less than tol, break out of the loop
            if norm(C) < tol
               break;
            end

        % Update S to be equal to S1
            S = S1;

        end
        fprintf(file, ' %f ', S);
        fprintf(file, '\n');
    end

    % Display the final value of norm(C)
    %fprintf('Final value : %f\n', norm(C));
end

% Close the file
fclose(file);
