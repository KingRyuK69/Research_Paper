function a=bistochastic(a,tol)
% return bistochastic matrix from input nonnegative matrix
if nargin<2, tol=0.001; end
s1=sum(a,2);
s2=sum(a);
while ((abs(max(s1)-1))>tol) | ((abs(max(s2)-1))>tol)
  a=a./s1;
  s1=sum(a,2);
  s2=sum(a);
  a=a./s2;
end
end