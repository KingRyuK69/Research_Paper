%m=input("Enter Mean:");
%d=input("Enter SD:");
%r = normrnd(m,d,[1,10]);
%disp(r)
t_dh = rand(5,4)
r=0
c=0
for i=0:5
    r = randi(5)
    c = randi(4)
    t_dh(r,c) = 0
end